/****************************************************************************
*                                                                           *
* File:         MAIN.H                                                   *
*                                                                           *
* Version:                                             			    *
*                                                                           *
* Created:      30.08.2001                                                  *
* Last Change:  30.08.2001                                                  *
*                                                                           *
* Author:       Chua Joo Ming                                               *
*                                                                           *
* Compiler:     KEIL C51 V4.10                                              *
*                                                                           *
* Description:  89C52RD2-Firmware for MFRC500 Demo Serial Reader            *
*                                                                           *
****************************************************************************/


#define AUTODELAY

#ifdef __SRC
 #define EXTERN
#else
 #define EXTERN		       	extern
#endif


// Common Defines

#define uchar                   unsigned char
#define uint                    unsigned int
#define ulong                   unsigned long

#define FALSE			0
#define TRUE 			1


#define INFO_CNT                23


// Ports

#define ON			1
#define OFF			0

// Configuration for the reader timeout counter 
// Timer 2 (modify OSC_FREQ if another crystal frequency is used)
#define OSC_FREQ                22118400L
				// *note: when using the 8051RD2 (in 6 clk instructiion cycle,
				//        use a crystal that is half the value state in OSC_FREQ.
				//	  Example: for OSC_FREQ=22118400, use 11059000 crystal.

#define BAUD_CNT 				7

#define	BAUD_115200				256 - (OSC_FREQ/192L)/115200L	// 255
#define	BAUD_57600				256 - (OSC_FREQ/192L)/57600L	// 254
#define	BAUD_38400				256 - (OSC_FREQ/192L)/38400L	// 253
#define	BAUD_28800				256 - (OSC_FREQ/192L)/28800L	// 252
#define	BAUD_19200				256 - (OSC_FREQ/192L)/19200L	// 250
#define	BAUD_14400				256 - (OSC_FREQ/192L)/14400L	// 248
#define	BAUD_9600				256 - (OSC_FREQ/192L)/9600L	// 244

#ifdef __SRC
 uchar code BaudRateTable[BAUD_CNT] = {
				       		BAUD_115200,
				       		BAUD_57600,
				       		BAUD_38400,
				       		BAUD_28800,
				       		BAUD_19200,
				       		BAUD_14400,
				       		BAUD_9600
				      };
#else
 extern uchar code BaudRateTable[BAUD_CNT];
#endif

#ifdef __SRC
 uint code CmpTable[BAUD_CNT + 1]   = {
				      		0x078,
				      		0x095,
				      		0x129,
				      		0x1BD,
				      		0x252,
				      		0x37A,
				      		0x4A3,
				      		0x6F4
				      };
#else
 extern uint code CmpTable[BAUD_CNT + 1];
#endif

// Serial Protocol

#define SOH                     0x01    // Start of header
#define STX                     0x02    // Start of text
#define ETX                     0x03    // End of text
#define ENQ                     0x05    // Enquire
#define ACK                     0x06    // Acknowledge
#define DLE                     0x10    // Data link escape
#define NAK                     0x15    // Not acknowledge


#define MAXREPCNT               2


#define CALL_isr_UART()         TI = 1


#define SER_BCC			0
#define SER_CRC			1

#define BCC_CHECKBYTECNT        1

// CCITT-CRC16 (x^16 + x^12 + x^5 + 1) => 0x11021

#define CRC_POLYNOM             0x1021
#define CRC_PRESET              0xFFFF
#define CRC_CHECKBYTECNT        2


// Receive States

#define RECV_STX                0
#define RECV_DATA_DLE_ETX       1
#define RECV_ETX                2

#define RECV_DLE                3
#define RECV_DLE_OR_NAK         4


// Values for checking the Data Length of the Commands

#define MINCMDNR		0x40
#define MAXCMDNR		0x57

#define CMDCNT                  MAXCMDNR - MINCMDNR + 1

#ifdef __SRC

 uchar code CmdLenTab[CMDCNT] = {

 // CmdNr: 0x40 ...
			 7,  1,  5,  4,  2,  0,  1, 17,  5,  5,  1,  1, 14,  1,  2,  0,

 // CmdNr: 0x50 ...        ... 0x57
			 1,  1,  2, 22,  1,  0,    3,   5};
#else

 extern uchar code CmdLenTab[CMDCNT];

#endif


// Serial Buffer

#define HEADER                  3

#define MAXDATA                 30

#define SERBUFLEN               HEADER + MAXDATA + CRC_CHECKBYTECNT + 1

#define SEQNR                   0

#define COMMAND                 1
#define STATUS                  1

#define LENGTH                  2

#define MODE                    3
#define BCNT                    3
#define ADR                     3
#define SERNR                   3
#define SIZE                    3
#define TIME                    3
#define TAGTYPE                 3
#define INFO                    3
#define CTLBYTE                 3
#define PORTBYTE                3
#define HLREQMODE               3

#define SECNR                   4
#define DATABYTES               4
#define VALUE                   4
#define BAUD                    4
#define SERNR_in                4
#define HL_SERNR                4
#define KEY_ADDR                4
#define POSITION		4
#define SEL_CNT			4

#define TKEY                    5
#define AUTHADD			5
#define DES_KEY			5
#define MKAC			5
#define CARD_ADDR               5
#define NUM			5

#define CIPHER			6

#define AUTHMODE                7

#define ADRCHKWR                8
#define HLAUTHMODE              8

#define DATACHKWR               9
#define HLSECNR                 9

#define NKEY6                   11
#define NKEY8                   13

#define QUIT                    30

// Timer 0

#define T_533_ms                14 // (533 ms)

#define START_T0(x)             Timer0Cnt = (x); TL0 = 0; TH0 = 0; TR0 = 1
#define STOP_T0()               TR0 = 0

#define CALL_isr_T0()           TR0 = 0; Timer0Cnt = 0; TF0 = 1


#ifndef NO_TIMER2

 // Timer 2

 #define RCAP2_50us             65536L - OSC_FREQ/240417L
 #define RCAP2_1ms              65536L - OSC_FREQ/12021L
 #define RCAP2_10ms             65536L - OSC_FREQ/1200L

 sfr16   RCAP2LH                = 0xCA;
 sfr16   T2LH                   = 0xCC;

#else

 #define SCON                   S0CON
 #define SBUF                   S0BUF
 #define ES                     ES0

#endif

#ifdef NOP_DELAY

 #define DELAY_us(x)            delay_50us_NOP()

#else

 #define DELAY_us(x)            for (i = 0; i < (uchar)(((x)*9)/20); i++)
 // 20 <= x <= 567

#endif


// Global Variables

EXTERN volatile bit             Idle;
EXTERN volatile bit             CmdReceived;

EXTERN volatile bit             DataDleReceived;
EXTERN volatile bit             CmdValid;
EXTERN volatile bit             LLfReady;
EXTERN volatile bit             SendReady;
EXTERN volatile bit             Quit;
EXTERN volatile bit             EnableRS422;
EXTERN volatile bit             EnableTransferCmd;
EXTERN volatile bit             Enable_LEDs;
EXTERN volatile bit          	AutoBaud;

#ifdef AUTODELAY
 EXTERN volatile bit           	DelayRateLocked;
 EXTERN volatile uchar  	DelayRate;
 EXTERN volatile uchar   	CmdCnt;

 #define MAXDELAYRATE			100
 #define AUTODELAY_FALLBACK		200
#endif

EXTERN volatile uchar   	RecvState;
EXTERN volatile uchar   	SendState;
EXTERN volatile uchar   	Index;
EXTERN volatile uchar   	RepCnt;
EXTERN volatile uchar   	Timer0Cnt;
EXTERN volatile uchar   	SeqNr;
EXTERN volatile uchar   	QuitStatus;
EXTERN volatile uchar   	CheckByteCnt;
                        
EXTERN volatile char    	BaudRate;
EXTERN volatile uchar   	Capt_L;
EXTERN volatile uchar   	Capt_H;
EXTERN volatile uint    	Capt;

EXTERN volatile uchar   idata   SerBuffer[SERBUFLEN];


// Global Prototypes

EXTERN void delay_8us_NOP(void);

EXTERN void delay_50us(uchar _50us);
EXTERN void delay_1ms(uchar _1ms);
EXTERN void delay_10ms(uint _10ms);

#ifdef NOP_DELAY
 EXTERN void delay_50us_NOP(void);
#endif

EXTERN uchar xtoa_h(uchar _byte);
EXTERN uchar xtoa_l(uchar _byte);

EXTERN void  auto_baud(void);


#undef EXTERN


/***************************************************************************/

