/****************************************************************************
*                                                                           *
* File:         MAIN.C                                                      *
*                                                                           *
* Version:      1.0                                       	       		    *
*                                                                           *
* Created:      21.06.2002                                                  *
* Last Change:  22.06.2002                                                  *
*                                                                           *
* Author:       Steven Jiang Chang                                               *
*                                                                           *
* Compiler:     KEIL C51 uVision2 V2.23                                              *
*                                                                           *
* Description:  89C52RD2-Firmware for MFRC500 Demo Serial Reader            *
*                                                                           *
****************************************************************************/

#define __SRC
#include "main.h"
#undef  __SRC

#include <string.h>
#include <intrins.h>
#include <stdio.h>
#include <m500a.h>
#include <p89c51rx.h>

#define MIS_CHK_OK              (0)
#define MIS_CHK_FAILED          (-1)
#define MIS_CHK_COMPERR         (-2)

// Function: mifs_request
#define IDLE                    0x00    
#define ALL                     0x01

sbit    RC500RST        	= P3^5;
sbit    RC500_CS         	= P2^7;
sbit    LED	        	= P3^4;
//sbit    LED	        	= P3^4;

// Release Number of the Firmware
uchar code SW_Rel[] = "\n\r MFRC500 V1.0 22.06.02 \n\r";

// Serial Number of the MFRC500 
uchar Snr_RC500[4];

static uint Crc;

// Local Prototypes
void init(void);


 code Nkey_a[6]    = {0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5};
 code Nkey_b[6]    = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};


/****************************************************************************
*                                                                           *
* Function:     main                                                        *
*                                                                           *
* Input:        -                                                           *
* Output:       -                                                           *
*                                                                           *
* Description:                                                              *
*                                                                           *
*                                                                           *
****************************************************************************/
void 	main (void)
{
  unsigned char counter,counter2;
  unsigned char mfout=2;//readbuf[16];
  unsigned char tt1[2];
  unsigned char status1;
  unsigned char cardserialno[4];
  unsigned char *sak1;
  unsigned char blockdata[16];
  init();
  M500PcdConfig();  	// Initialise the RC500
	                // must be call in the initialisation
  PcdReadE2(8,4,Snr_RC500); // Read out the MFRC500 serial number and store it
    M500PcdMfOutSelect(mfout);

  for (counter=0;counter<20;counter++)
 {
  	status1 = M500PiccRequest(PICC_REQALL, tt1);
  	if (status1==MI_OK)
		status1=M500PiccAnticoll(0,cardserialno);
  	if (status1==MI_OK)
    	status1=M500PiccSelect(cardserialno,sak1);
  	if (status1==MI_OK)
	  	status1 = M500PiccAuth(PICC_AUTHENT1A, cardserialno, 1, 4);
  	if (status1 ==MI_OK)
      	status1=M500PiccRead(4, blockdata);
  	for ( counter2=0;counter2<16;counter2++)
       	blockdata[counter2]=counter;
  	if (status1 ==MI_OK)
	  	status1 = M500PiccWrite(4,blockdata);                
     	
  }
}


/****************************************************************************
*                                                                           *
* Function:     init                                                        *
*                                                                           *
* Input:        -                                                           *
* Output:       -                                                           *
*                                                                           *
* Description:                                                              *
*                                                                           *
*                                                                           *
****************************************************************************/

void 	init (void)
{
  RC500RST    = FALSE;
  RC500_CS    = TRUE;	// Enable the CS for RC500
			
  CmdReceived = FALSE;
  CmdValid    = FALSE;
  Quit        = FALSE;
  LLfReady    = TRUE;
  SendReady   = TRUE;
  Idle        = TRUE;

  RepCnt      = 0;

  RecvState   = RECV_STX;

  EnableTransferCmd = FALSE;

  CheckByteCnt = BCC_CHECKBYTECNT;

#ifdef AUTODELAY
  DelayRate = 0;
  DelayRateLocked = TRUE;
#endif

  PCON = 0x80;              	// SMOD = 1;
  SCON = 0x50;              	// Mode 1, 8-bit UART, enable receiption
  
  AutoBaud = TRUE;
  TMOD     = 0x20;      	// Timer 1, mode 2, 8-bit auto reload,
  		  		// Timer 0, mode 0, 13-bit counter
  Capt_L   = 0;
  Capt_H   = 0;
  
  LED = OFF;
  delay_10ms(50);
  LED = ON;

  IT0 = 1;    			// Config ext0 as edge trigger for RC500
  EX0 = 1; 			// Enable ext0 interrupt for RC500

  EA = TRUE;			// Enable all interrupts

}



/****************************************************************************
*                                                                           *
* Function:     delay_50us                                                  *
*                                                                           *
* Input:        _50us                                                       *
* Output:       -                                                           *
*                                                                           *
* Description:                                                              *
*                                                                           *
* Time delay with a resolution of 50 us.                                    *
*                                                                           *
****************************************************************************/

void 	delay_50us (uchar _50us)
{

  RCAP2LH = RCAP2_50us;
  T2LH    = RCAP2_50us;
  ET2 = 0; 	// Disable timer2 interrupt
  T2CON = 0x04;	// 16-bit auto-reload, clear TF2, start timer
  
  while (_50us--)
  {
	while (!TF2);
	TF2 = FALSE;
  }

  TR2 = FALSE;

}


/****************************************************************************
*                                                                           *
* Function:     delay_1ms                                                   *
*                                                                           *
* Input:        _1ms                                                        *
* Output:       -                                                           *
*                                                                           *
* Description:                                                              *
*                                                                           *
* Time delay with a resolution of 1 ms.                                     *
*                                                                           *
****************************************************************************/

void 	delay_1ms (uchar _1ms)
{

  RCAP2LH = RCAP2_1ms;
  T2LH    = RCAP2_1ms;
  ET2 = 0; 	// Disable timer2 interrupt
  T2CON = 0x04;	// 16-bit auto-reload, clear TF2, start timer
  
  while (_1ms--)
  {
	while (!TF2);
	TF2 = FALSE;
  }
  TR2 = FALSE;

}


/****************************************************************************
*                                                                           *
* Function:     delay_10ms                                                  *
*                                                                           *
* Input:        _10ms                                                       *
* Output:       -                                                           *
*                                                                           *
* Description:                                                              *
*                                                                           *
* Time delay with a resolution of 10 ms.                                    *
*                                                                           *
****************************************************************************/

void 	delay_10ms (uint _10ms)
{

  RCAP2LH = RCAP2_10ms;
  T2LH    = RCAP2_10ms;
  ET2 = 0; 	// Disable timer2 interrupt
  T2CON = 0x04;	// 16-bit auto-reload, clear TF2, start timer
  
  while (_10ms--)
  {
	while (!TF2)
	{
	  if (CmdValid || CmdReceived)
	  {
		TR2 = FALSE;
		TF2 = FALSE;
		return;
	  }
	}
	TF2 = FALSE;
  }
  TR2 = FALSE;

}


#ifdef NOP_DELAY

/****************************************************************************
*                                                                           *
* Function:     delay_50us_NOP                                              *
*                                                                           *
* Input:        -                                                           *
* Output:       -                                                           *
*                                                                           *
* Description:                                                              *
*                                                                           *
* Zeitverz�gerung von 50 �s.                                                *
*                                                                           *
****************************************************************************/

void 	delay_50us_NOP (void)
{
  uchar i;
  
  for(i=0; i<81; i++) _nop_();	
}

#endif


/****************************************************************************
*                                                                           *
* Function:     delay_8us_NOP                                               *
*                                                                           *
* Input:        -                                                           *
* Output:       -                                                           *
*                                                                           *
* Description:                                                              *
*                                                                           *
*                                                                           *
****************************************************************************/

void 	delay_8us_NOP (void)
{
  uchar i;
  
  for(i=0; i<14; i++) _nop_();	
}

#pragma aregs


/****************************************************************************
*                                                                           *
* Function:     xtoa_h                                                      *
*                                                                           *
* Input:        _byte                                                       *
* Output:       ASCII High-Nibble                                           *
*                                                                           *
* Description:                                                              *
*                                                                           *
* Wandelt das High-Nibble des �bergebenen Bytes in ein ASCII-Zeichen um.    *
*                                                                           *
****************************************************************************/

uchar 	xtoa_h (uchar _byte)
{
  uchar nibble = _byte >> 4;

  return ((nibble > 9)? nibble + 'A' - 10 : nibble + '0');
}


/****************************************************************************
*                                                                           *
* Function:     xtoa_l                                                      *
*                                                                           *
* Input:        _byte                                                       *
* Output:       ASCII Low-Nibble                                            *
*                                                                           *
* Description:                                                              *
*                                                                           *
* Wandelt das Low-Nibble des �bergebenen Bytes in ein ASCII-Zeichen um.     *
*                                                                           *
****************************************************************************/

uchar 	xtoa_l (uchar _byte)
{
  uchar nibble = _byte & 0x0F;

  return ((nibble > 9)? nibble + 'A' - 10 : nibble + '0');
}


/****************************************************************************
*                                                                           *
* Function:     isr_timer0                                                  *
*                                                                           *
* Input:        -                                                           *
* Output:       -                                                           *
*                                                                           *
* Description:                                                              *
*                                                                           *
*                                                                           *
****************************************************************************/

void 	isr_timer0 (void) interrupt 1 using 2
{
  if (Timer0Cnt)
  {
	--Timer0Cnt;
  }
  else
  {
	STOP_T0();

#ifdef AUTODELAY
	if (DelayRate < MAXDELAYRATE && CmdCnt > 0)
	{
	  DelayRate++;
	  DelayRateLocked = FALSE;
	}
#endif

	RecvState = RECV_STX;

	if (!SendReady && LLfReady)
	{
	  if (RepCnt < MAXREPCNT)
	  {
		RepCnt++;
		CALL_isr_UART();
	  }
	  else
	  {
		RepCnt = 0;
		Quit = FALSE;
		SendReady = TRUE;
	  }
	}
  }
}


/***************************************************************************/
