/*
*         Copyright (c), Philips Semiconductors Gratkorn / Austria
*
*                     (C)PHILIPS Electronics N.V.2000
*       All rights are reserved. Reproduction in whole or in part is 
*      prohibited without the written consent of the copyright owner.
*  Philips reserves the right to make changes without notice at any time.
* Philips makes no warranty, expressed, implied or statutory, including but
* not limited to any implied warranty of merchantability or fitness for any
*particular purpose, or that the use will not infringe any third party patent,
* copyright or trademark. Philips must not be liable for any loss or damage
*                          arising from its use.
*/

#ifndef MFRC500_H
#define MFRC500_H

#ifdef __cplusplus
extern "C"
{
#endif

// General Include File for serveral defines concerning conditional library
// compilation and microcontroller usage
#include "OsDefs.h"

#define PICC_REQIDL        0x26         //!< request idle
#define PICC_REQALL        0x52         //!< request all
#define PICC_ANTICOLL1     0x93         //!< anticollision level 1 106 kBaud
#define PICC_ANTICOLL2     0x95         //!< anticollision level 2
#define PICC_ANTICOLL3     0x97         //!< anticollision level 3
#define PICC_AUTHENT1A     0x60         //!< authentication using key A
#define PICC_AUTHENT1B     0x61         //!< authentication using key B
#define PICC_READ          0x30         //!< read block
#define PICC_WRITE         0xA0         //!< write block
#define PICC_DECREMENT     0xC0         //!< decrement value
#define PICC_INCREMENT     0xC1         //!< increment value
#define PICC_RESTORE       0xC2         //!< restore command code
#define PICC_TRANSFER      0xB0         //!< transfer command code
#define PICC_HALT          0x50         //!< halt

/*
* This function has to be called before the first data is written to the 
* MF RC500 in order to perform the internal configuration. A reset of the 
* MF RC500 is done  and several registers are set. 
*/
FCT_PREF Mf500PcdConfig(void);

/*
* The MF RC500 reader IC configured in the slave configuration is able to 
* communicate with another MF RC500 configured in the master configuration 
* via the digital <em>MFin</em> and <em>MFOut</em> pins. 
*
* The master MF RC500 reader IC sends commands and data using the 
* <em>MFOut</em> pin. The  slave reader IC receives the data via 
* <em>MFin</em> pin. Sending data back from the slave IC is done connecting the
* <em>MFOut</em> for the slave IC and <em>MFin</em> for the master MF RC500.
*
* In this configuration  the slave module can not be initialized by the 
* microcontroller because only the <em>mifare in/out</em> interface is 
* connected between both MF RC500's. The slave module has to be initialized 
* before the connection is established. During this initialization  the 
* appropriate parameter settings are written to the E2PROM. 
* After POR (power on reset) the IC reads these settings and initializes 
* itself automatically as slave IC.	
*
* Additionally, it is possible to connect the slave reader Ic to the �C 
* to have the possibility to change the setting in the application later.	
*/
FCT_PREF Mf500ActiveAntennaSlaveConfig(void);

/*
* This function initializes the master reader IC to use it in an active antenna
* configuration. 
*
* This function is additional to the standard configuration 
* <em>Mf500PcdConfig</em>. 
*
* The MF RC500 reader IC configured in the master 
* configuration is able to communicate with another MF RC500 configured in the 
* slave configuration  via the digital <em>MFin</em> and <em>MFout</em> pins. 
* The corresponding slave configuration routine for the slave MF RC 500 can be 
* initialized by the function <em>MF500ActiveAntennaSlaveConfig</em>. 
*/
FCT_PREF Mf500ActiveAntennaMasterConfig(void);

/* 
* Set MIFARE PCD (Proximity Coupling Device) with
* default values for the baudrate divider (106 kBaud). 
*/
FCT_PREF Mf500PcdSetDefaultAttrib(void);


/* 
* This function accesses the reader module and activates sending the REQ code 
* to the MIFARE� card. After sending the command to the card  the function 
* waits for the card's answer. 
*
* Please note, that this function has an identical functionality to the 
* Mf500PiccCommonRequest function, which is desribed by ISO 14443A command set.
* Depending on the Request Code and the state of the cards in the field  
* all cards reply with their Tag-Type synchronously. The time between end of the
* Request command and start of reply of the card is exactly 8 * 9.44 us long.
* The Tag-Type field is 16 bits long and only one  bit out of 16 is set.
*
* When cards with different Tag-Types are in field, the MF RC500 is able to 
* identify all types of  cards in the RF-field. Further more, the Tag-Type 
* is used to identify a card with cascaded serial number. 
* Double and Triple serial numbers are possible.
*
* Relevant bit positions LSByte:
* <ul> 
*  <li> [8..7] UID size
*   <ul> 
*    <li> 00 standard 32 bit long UID
*    <li> 01 UID size double (56 bit long)
*    <li> 10 UID size triple (80 bit long)
*   </ul>
*  <li> [5..1] if any bit is set, frame anticollision is supported; 
*              tag type recognition
* </ul>
*
*
* The complete MSByte is RFU.
*
* Note: Future cards will work also with other request codes.
*/
FCT_PREF Mf500PiccRequest(unsigned char req_code, 
                       unsigned char *atq);
                       
/*
* Please note, that this function has an identical functionallity 
* to function Mf500PiccRequest.
*/
FCT_PREF Mf500PiccCommonRequest(unsigned char req_code, 
                             unsigned char *atq);  

/*
* This function calls MF500PiccCascAnticoll with select_code 0x93 to perform 
* the anitcollision for MIFARE�  Classic card ICs . 
*/
FCT_PREF Mf500PiccAnticoll (unsigned char bcnt,
                         unsigned char *snr);

/*
* Corresponding to the specification in ISO 14443 A, this function handles 
* extended serial numbers. Therefore more than one select_code is possible. 
*
* The function transmits a select code and all ready tags are responding. 
* The return value of this function will be the serial number of one PICC. 
*/                     
FCT_PREF Mf500PiccCascAnticoll (unsigned char select_code,
                             unsigned char bcnt,
                             unsigned char *snr);                     

/*
* This function selects a card by the specified serial number. All other cards 
* in the field fall back into the idle mode and they are not longer involved 
* during the communication. The actual select procedure is done by the function 
* <em>Mf500PiccCascSelect</em>, which is called with select_code 0x93. 
*/             
FCT_PREF Mf500PiccSelect(unsigned char *snr, 
                      unsigned char *sak);

/*
* This functions selects a UID level, depending on select code and
* returns a Select Acknowledge byte.
*
* Corresponding to the specification in ISO 14443 A, this function
* is able to handle extended serial numbers. So that more than
* one select_codes are possible.
*
* Relevant bit positions in SAK are 6 and 1. All other bit positions
* are RFU.
*
* Valid combinations are:
* <ul>
*  <li> XX1XX0XX UID complete, ATS available
*  <li> XX0XX0XX UID complete, ATS not available
*  <li> XXXXX1XX UID not complete
* </ul>
*/
FCT_PREF Mf500PiccCascSelect(unsigned char select_code, 
                             unsigned char *snr, 
                             unsigned char *sak); 

/*
* This function performs a Request-Idle, Anticollision, Select sequence  to 
* activate the PICC and change its state from IDLE to ACTIVE state. 
* Cascaded serialnumbers are handled correctly. 
*/
FCT_PREF Mf500PiccActivateIdle(unsigned char br,
                           unsigned char *atq, 
                           unsigned char *sak, 
                           unsigned char *uid, 
                           unsigned char *uid_len);
 
/*
* This function performs a Request-All, Anticollision, Select sequence  to 
* activate the PICC and change its state from IDLE to ACTIVE state. 
* Cascaded serialnumbers are handled correctly. 
*/
char Mf500PiccActivateWakeup(unsigned char br,
                             unsigned char *atq, 
                             unsigned char *sak,
                             unsigned char *uid, 
                             unsigned char uid_len);

/*
* This function authenticates one card's sector (according to the  block 
* address) using the specified master key A or B,  addressed with auth_mode .  
* Having send  the command to the card the  function waits for the card's 
* answer. This function is calling compatible with authentication functions 
* former reader IC's. The keys are stored by the  microcontroller, which should
* be capable for the key management. 
*/
FCT_PREF Mf500PiccAuth(unsigned char auth_mode, 
                      unsigned char key_sector, 
                      unsigned char block);   
  
/*
* This function authenticates one card's sector using the specified 
* mode. After sending the command to the card the 
* function waits for the card's answer.
* The keys for authentication have to be stored at the 
* corresponding location in the E2PROM.
*/
FCT_PREF Mf500PiccAuthE2( unsigned char auth_mode, 
                         unsigned char *snr,      
                         unsigned char key_sector,
                         unsigned char block); 

/*
* To pass the authentication procedure a coded master key is needed and this 
* key has to be stored in the MF RC500's internal key buffer. The coding of the 
* 6 byte long uncoded master key to a 12 byte long coded master key is 
* erformed using this function.
*/                     
FCT_PREF Mf500HostCodeKey(unsigned char *uncoded, 
                         unsigned char *coded); 

/*
* This function stores the keys in the reader internal E2PROM.
* After successful loading, these keys are available for the use by
* function <em>Mf500PiccAuthE2</em>.
*/                     
FCT_PREF Mf500PcdLoadKeyE2(unsigned char key_type,
                          unsigned char sector,
                          unsigned char *uncoded_keys); 
                     
/*
* This function authenticates one card's sector using keys stored in the 
* �Controller. The keys are first loaded to the reader module and used for 
* authentication of the specified sector. In order to get the  required keys 
* coded, the function Mf500HostCodeKey has to be used . 
*/                     
FCT_PREF Mf500PiccAuthKey(unsigned char auth_mode,
                         unsigned char *snr,   
                         unsigned char *keys,  
                         unsigned char sector);   
                     
/*
* This function directly reads out a 16 byte block from the specified card's 
* blockaddress <em>addr</em>. 
*/                        
FCT_PREF Mf500PiccRead(unsigned char addr,  
                       unsigned char* data);
                  
/*
* This function writes a 16 byte block to the specified card's block address 
* <em>addr</em>. Having send the command the card indicates with an ACK, that 
* the direct memory access is possible. Having received the ACK, the MF RC500 
* sends the 16 bytes data block and waits for an ACK again. In case of an error
* a return code  according  to the MF RC500's error flags is generated. 
*/                  
FCT_PREF Mf500PiccWrite(unsigned char addr,
                       unsigned char *data);

/*
* This function performs the INCREMENT, DECREMENT and RESTORE command. Precondition 
* for success is, that the data block is formatted as value block. 
*
* For INCREMENT and DECREMENT, the command doesn't write back the value to the memory 
* location directly, but loads the transfer buffer with the increased value,
* which could be transferred to any authenticated block by the TRANFER command.
*
* The RESTORE command loads the transfer buffer with the value stored at datablock 
* address, while the 
* given value is only a dummy value, which only have to be in valid range. 
* With a subsquent TRANSFER command a backup management for Value Blocks is 
* established.
*
* After sending the command to the card the function waits for the 
* card's answer. In case of an error <em>Mf500PiccValue()</em>
* generates a return code according to the MF RC's error flags, otherwise 
* the value is sent to the card and then it waits for a NACK. As an exception 
* in this protocol step 
* only a NACK is sent by the card in case of an error. Thus, the function 
* is successful, if a time out occurs. 
*
* After the calculation is done,  a TRANSFER is automatically
* performed to the block address trans_addr. After sending the command to
* the card the function waits for the card's answer 
* and generates a return code according to the MF RC's error flags. 
* A TRAN command is only possible directly after a RESTORE, INCREMENT or 
* DECREMENT command.
*
* The value inside a Value Block is four bytes wide and stored tow times
* in normal and one time in bit-inverted manner for data security issues. 
* Additionally the initial address of the Value Block is stored two times 
* normal and two times bit-inverted. In case of a backup of a Value Block, 
* this addres contains the original address of the Value Block.
*
* Note: Only positive numbers are alowed for the parameter <em>value</em>.
*
*/
FCT_PREF Mf500PiccValue(unsigned char dd_mode, 
                       unsigned char addr, 
                       unsigned char *value,
                       unsigned char trans_addr);

/*
* This function executes calculations on value debit blocks with cards, that 
* support automatic transfer (MIFARE light, MIFARE PLUS, MIFARE PRO,
* MIFARE PROX, ...). 
*
* After sending the command 
* to the card the function waits for the card's answer. In case of an error 
* it generates a return code according 
* to the MF RC's error flags. 
*/
FCT_PREF Mf500PiccValueDebit(unsigned char dd_mode, 
                             unsigned char addr, 
                             unsigned char *value);

/*
* This function exchanges data blocks between the <b>PCD</b> and <b>PICC</b>. 
*
* ATTENTION: if <em>append_crc</em> is enabled, two CRC bytes are included in 
* <em>send_bytelen</em> and <em>rec_bytelen</em>. The received CRC bytes in the
* receive buffer are always set to zero. 
*/
FCT_PREF Mf500PiccExchangeBlock(unsigned char *send_data,
                               unsigned char send_bytelen,
                               unsigned char *rec_data,  
                               unsigned char *rec_bytelen,
                               unsigned char append_crc, 
                               unsigned short  timeout );                  

/*
* This function sets a MIFARE� CLassic compatible card into the halt state. 
* Having send the command to the card, the function does not expect a cards 
* response. Only in case of any error the card sends back a NACK. If the 
* command was successful, the card does not return with an ACK. Thus, the 
* function is successful, if a timeout in the MF RC500 is indicated.
*/                  
FCT_PREF Mf500PiccHalt(void);


#ifdef __cplusplus
}
#endif

#endif