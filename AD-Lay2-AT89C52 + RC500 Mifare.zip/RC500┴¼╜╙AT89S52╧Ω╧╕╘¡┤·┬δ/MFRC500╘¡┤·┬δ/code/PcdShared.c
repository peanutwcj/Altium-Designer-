///////////////////////////////////////////////////////////////////////////////
//    Copyright (c), Philips Semiconductors Gratkorn
//
//                  (C)PHILIPS Electronics N.V.2000
//                     All rights are reserved. 
//  Philips reserves the right to make changes without notice at any time.
// Philips makes no warranty, expressed, implied or statutory, including but
// not limited to any implied warranty of merchantibility or fitness for any
//particular purpose, or that the use will not infringe any third party patent,
// copyright or trademark. Philips must not be liable for any loss or damage
//                          arising from its use.
///////////////////////////////////////////////////////////////////////////////
#define DLL_EXPORT      // library source module definition

#include <string.h>
#include <stdio.h>

#include <RICReg.h>

#include <PcdShared.h>
#include <uCInit.h>
#include <RcCommunication.h>
#include <PcCommunication.h>
#include <CPURegs.h>
#include <PcdUtils.h>
#include <MfErrNo.h>

///////////////////////////////////////////////////////////////////////
//      M I F A R E   M O D U L E   R E S E T 
///////////////////////////////////////////////////////////////////////
char PcdReset(void)
{
   char status = MI_OK;

   SleepMs(500);     	// wait     
   READER_RESET;   		// reset RC500
   SleepMs(100);      	// wait
   READER_CLEAR_RESET; // clear reset pin


   GT_vInitTmr(TIMER_3,0x87); // stop timer, count down with a period of 52 us
   T3IC  = 0x00;               // reset interrupt request 
   GT_vLoadTmr(TIMER_3,0xAFFF);   // 0x9FFF * 52 us = 2.1 s
   GT_vStartTmr(TIMER_3);   // start timer

   // wait until reset command recognized
   while (((ReadRawRC(RegCommand) & 0x3F) != 0x3F) && !T3IR);

   // while reset sequence in progress
   while ((ReadRawRC(RegCommand) & 0x3F) && !T3IR);

   GT_vStopTmr(TIMER_3);  // stop timeout counter

   if (T3IR)
   {
      status = MI_RESETERR; // respose of reader IC is not correct
      T3IR   = 0;
   }

   if (status == MI_OK)
   {
      WriteRawRC(RegPage,0x80); // Dummy access in order to determine the bus 
                                // configuration
      // necessary read access 
      // after first write access, the returned value
      // should be zero ==> interface recognized
      if (ReadRawRC(RegCommand) != 0x00)
      {                           
          status = MI_INTERFACEERR;
      }
	  else
	  {
          // sequence is ok
	  }
   }

   return status;
}

//////////////////////////////////////////////////////////////////////
//           E X C H A N G E   B Y T E   S T R E A M
///////////////////////////////////////////////////////////////////////
char ExchangeByteStream(unsigned char Cmd,
                        unsigned char *send_data,
                        unsigned char send_bytelen,
                        unsigned char *rec_data,  
                        unsigned char *rec_bytelen)
{
   signed char status = MI_OK;

   FlushFIFO();    // empty FIFO
   ResetInfo(MInfo); // initialise ISR Info structure

   if (send_bytelen > 0)
   {
      memcpy(MSndBuffer,send_data,send_bytelen); // write n bytes 
      MInfo.nBytesToSend = send_bytelen;
      // write load command
      status = PcdSingleResponseCmd(Cmd,
                      MSndBuffer,
                      MRcvBuffer,
                      &MInfo);
      if ( status == MI_OK )
      {
         *rec_bytelen = MInfo.nBytesReceived;
         if (*rec_bytelen)
         {
            memcpy(rec_data,MRcvBuffer,MInfo.nBytesReceived);
         }
      }
   }
   else
   {
      status = MI_WRONG_PARAMETER_VALUE;
   }
   return status;
}                                   

///////////////////////////////////////////////////////////////////////
//          R E A D   S N R   O F   R E A D E R   I C
///////////////////////////////////////////////////////////////////////
char PcdGetSnr(unsigned char* snr)
{
   signed char status;
   
   status = PcdReadE2(0x08,0x04,snr);
   return status;
}


///////////////////////////////////////////////////////////////////////
//          E E P R O M   R E A D   
///////////////////////////////////////////////////////////////////////
char PcdReadE2(unsigned short startaddr,
               unsigned char length,
               unsigned char* data)
{
   char status = MI_OK;

     // ************* Cmd Sequence ********************************** 
     ResetInfo(MInfo);   
     MSndBuffer[0] = startaddr & 0xFF;
     MSndBuffer[1] = (startaddr >> 8) & 0xFF;
     MSndBuffer[2] = length;
     MInfo.nBytesToSend   = 3;
     status = PcdSingleResponseCmd(PCD_READE2,
                         MSndBuffer,
                         MRcvBuffer,
                         &MInfo);
    if (status == MI_OK)
    {
       memcpy(data,MRcvBuffer,length);
    }
    else   // Response Processing
    {
       data[0] = 0;
    }
    return status ;
}


///////////////////////////////////////////////////////////////////////
//          E E P R O M   W R I T E 
///////////////////////////////////////////////////////////////////////
char PcdWriteE2(  unsigned short startaddr,
                      unsigned char length,
                      unsigned char* data)
{
   char status = MI_OK;

     // ************* Cmd Sequence ********************************** 
   ResetInfo(MInfo);   
   MSndBuffer[0] = startaddr & 0xFF;
   MSndBuffer[1] = (startaddr >> 8) & 0xFF;
   memcpy(MSndBuffer + 2,data,length);

   MInfo.nBytesToSend   = length + 2;
         
   status = PcdSingleResponseCmd(PCD_WRITEE2,
                   MSndBuffer,
                   MRcvBuffer,
                   &MInfo); // write e2
   return status;
}   

//////////////////////////////////////////////////////////////////////
//                 R E S E T 
///////////////////////////////////////////////////////////////////////
char PcdRfReset(unsigned short ms)
{
   char   status = MI_OK;

   ClearBitMask(RegTxControl,0x03);  // Tx2RF-En, Tx1RF-En disablen
   if (ms > 0)
   {
      SleepUs(((ms * 1000) - 40) / 2);                      // Delay for 1 ms 
      SetBitMask(RegTxControl,0x03);    // Tx2RF-En, Tx1RF-En enable
   }

   return status;
}

