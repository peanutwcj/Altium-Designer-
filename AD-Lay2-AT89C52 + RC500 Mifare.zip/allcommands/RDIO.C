///////////////////////////////////////////////////////////////////////////////
//    Copyright (c), Philips Semiconductors Gratkorn
//
//                  (C)PHILIPS Electronics N.V.2000
//       All rights are reserved. Reproduction in whole or in part is 
//      prohibited without the written consent of the copyright owner.
//  Philips reserves the right to make changes without notice at any time.
// Philips makes no warranty, expressed, implied or statutory, including but
// not limited to any implied warranty of merchantibility or fitness for any
//particular purpose, or that the use will not infringe any third party patent,
// copyright or trademark. Philips must not be liable for any loss or damage
//                          arising from its use.
///////////////////////////////////////////////////////////////////////////////
#include <rdio.h>
#include <main.h>
#include <p89c51rx.h>

///////////////////////////////////////////////////////////////////////////////
//                 Module Definitions
///////////////////////////////////////////////////////////////////////////////
#define GetRegPage(adr) (0x80 | (adr>>3))

unsigned char xdata ini _at_ 0x7f00;    // move base address to 0x7f00
unsigned char xdata *GpBase = &ini;   // redirect pointer to base address

///////////////////////////////////////////////////////////////////////////////
//                 Open Reader Communication
///////////////////////////////////////////////////////////////////////////////
char OpenIO(void)
{
   GpBase = &ini;
   P2_7 = 0;	// Enable the CS for RC500
   return 0x00;
}

///////////////////////////////////////////////////////////////////////////////
//                 Close Reader Communication
///////////////////////////////////////////////////////////////////////////////
void CloseIO(void)
{
   GpBase = 0xff00;
   P2_7 = 1;	// disable the CS for RC500
}

///////////////////////////////////////////////////////////////////////////////
//          G E N E R I C    W R I T E
///////////////////////////////////////////////////////////////////////////////
void WriteIO(unsigned char Address, unsigned char value)
{
   WriteRawIO(Address,value);                 // write value at the specified 
                                              // address
}

///////////////////////////////////////////////////////////////////////////////
//          G E N E R I C    R E A D
///////////////////////////////////////////////////////////////////////////////
unsigned char ReadIO(unsigned char Address)
{
   static unsigned char c;
   c = ReadRawIO(Address);                    // read value at the specified 
                                           // address
   return c;
}  

#ifndef SEC_NO_MICORE
///////////////////////////////////////////////////////////////////////////////
//     W R I T E   S E V E R A L   M E M O R Y   L O C A T I O N S 
///////////////////////////////////////////////////////////////////////////////
void WriteIOBlock(unsigned char *Addr_Data, unsigned short len)
{
   static unsigned short cnt;

   for (cnt = 0; cnt < len; cnt++)
   {
        // write value at the specified address
       WriteRawIO(Addr_Data[cnt*2],Addr_Data[cnt * 2 + 1]); 
   }
}

///////////////////////////////////////////////////////////////////////////////
//     R E A D   S E V E R A L   M E M O R Y   L O C A T I O N S 
///////////////////////////////////////////////////////////////////////////////
void ReadIOBlock(unsigned char* Addr_Data, unsigned short len)
{
   static unsigned short cnt;

   for (cnt = 0; cnt < len; cnt)
   {
       Addr_Data[cnt*2 + 1] = ReadRawIO(Addr_Data[cnt*2]);// read value at the 
                                                      // specified address
   }
}  
#endif
