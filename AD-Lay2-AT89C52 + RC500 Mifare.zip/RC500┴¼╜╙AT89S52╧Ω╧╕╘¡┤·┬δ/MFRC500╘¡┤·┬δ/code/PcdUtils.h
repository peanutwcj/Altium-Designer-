 ///////////////////////////////////////////////////////////////////////////////
//    Copyright (c), Philips Semiconductors Gratkorn
//
//                     (C)PHILIPS Electronics N.V. 2000
//                        All rights are reserved. 
//  Philips reserves the right to make changes without notice at any time.
// Philips makes no warranty, expressed, implied or statutory, including but
// not limited to any implied warranty of merchantibility or fitness for any
//particular purpose, or that the use will not infringe any third party patent,
// copyright or trademark. Philips must not be liable for any loss or damage
//                          arising from its use.
///////////////////////////////////////////////////////////////////////////////

#ifndef PCDUTILS_H
#define PCDUTILS_H

#include <MfErrno.h>

#ifdef __cplusplus
extern "C"
{
#endif

/// maximal transfer buffer size between PCD and PICC
#define MAX_RF_BUF_SIZE       256

/*
* The communication channel between PCD and PICC needs some RAM
* space for intermediate data storage. This space is also the 
* limitation for the maximum data stream length for a single transaction.
*
* Because of the communication structure between PCD and PICC the same
* buffer can be used for transmitting and receiving.
*
*/
extern volatile unsigned char RxTxBuffer[MAX_RF_BUF_SIZE];

/* 
* Data, which have to be passed between ISR and other functions are
* colleted within one structure. 
*/ 

#define ResetInfo(info)    \
            info.cmd            = 0; \
            info.status         = MI_OK;\
            info.irqSource      = 0; \
            info.nBytesSent     = 0; \
            info.nBytesToSend   = 0; \
            info.nBytesReceived = 0; \
            info.nBitsReceived  = 0; \
            info.collPos        = 0; 

/// struct definition for a communication channel between function and ISR
typedef struct 
         {
            unsigned char  cmd;           //!< command code 
            char           status;        //!< communication status
            unsigned char  nBytesSent;    //!< how many bytes already sent
            unsigned char  nBytesToSend;  //!< how many bytes to send
            unsigned char  nBytesReceived;//!< how many bytes received
            unsigned short nBitsReceived; //!< how many bits received
            unsigned char  irqSource;     //!< which interrupts have occured
            unsigned char  collPos;       /*!< at which position occured a
                                          collision*/
         } MfCmdInfo;

//! Communication Structure
extern volatile MfCmdInfo     MInfo;                  


/*
FIFO length of the reader IC
*/
extern unsigned char MFIFOLength;


extern volatile unsigned char *MSndBuffer;
// receive buffer for general use
extern volatile unsigned char *MRcvBuffer;


/*
* This function is a central routine in the communication chain between
* PCD and PICC. 
*/ 
void SingleResponseIsr(void);

/*
* This function provides the central interface to the reader module.
* Depending on the "cmd"-value, all necessary interrupts are enabled
* and the communication is started. While the processing is done by
* the reader module, this function waits for its completion.
*
* It's notable, that the data in the <em>send byte stream</em> is written 
* to the FIFO of the reader module by the ISR itself. Immediate after 
* enabling the interrupts, the LoAlert interrupt is activated.
*
* The ISR writes the data to the FIFO. This function is not directly involved
* in writing or fetching data from FIFO, all work is done by the 
* corresponding ISR.After command completion, the error status is evaluated and 
* returned to the calling function.
*/ 
char PcdSingleResponseCmd(unsigned char cmd,
                volatile unsigned char* send, 
                volatile unsigned char* rcv,
                volatile MfCmdInfo *info);

/*
* This function sets a RF communication time out value. Every communication 
* between the reader IC and the card  is guarded by a  timeout value. 
*
* The timeout value is measured between the last bit sent to the tag and the 
* first bit received from the tag. 
*/
void PcdSetTmo(unsigned char tmoLength);

/*              
* This function performs a read - modify - write sequence
* on the specified register. All bits with a 1 in the mask
* are set - all other bits keep their original value.
*/
void SetBitMask(unsigned char reg,unsigned char mask);

/*              
* This function performs a read - modify - write sequence
* on the specified register. All bits with a 1 in the mask
* are cleared - all other bits keep their original value.
*/
void ClearBitMask(unsigned char reg,unsigned char mask);

/*              
* This function erases  all remaining data in the MF RC 500's FIFO .
* Before writing new data or starting a new command, all remaining data 
* from former  commands should be deleted.
*/
void FlushFIFO(void);


#ifdef __cplusplus
}
#endif

#endif