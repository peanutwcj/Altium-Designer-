///////////////////////////////////////////////////////////////////////////////
//    Copyright (c), Philips Semiconductors Gratkorn
//
//                     (C)PHILIPS Electronics N.V. 2000
//       All rights are reserved. Reproduction in whole or in part is 
//      prohibited without the written consent of the copyright owner.
//  Philips reserves the right to make changes without notice at any time.
// Philips makes no warranty, expressed, implied or statutory, including but
// not limited to any implied warranty of merchantibility or fitness for any
//particular purpose, or that the use will not infringe any third party patent,
// copyright or trademark. Philips must not be liable for any loss or damage
//                          arising from its use.
///////////////////////////////////////////////////////////////////////////////
//
// Projekt         : M500
// Files           : M500A.h M500A.c
// Created         : 01.04.00
//
// COMMENT: 
//	         This header file can be used either for a uC environment or for 
//           Win32 DLL. Therefore the header MfOsDefs.h is included. Depending 
//           on the environment different definitions are used for "FCT_PREF". 
//           For the microcontroller system, all functions have the return type
//          "char". For the Win32 DLL the return types are changed to "long". 
//           Further more the DLL functions need to be exported, so the 
//           corresponding declarations are made. 
// MODIFICATIONS:
// 01.04.00  HB  first issue
///////////////////////////////////////////////////////////////////////////////
#ifndef M500A_H
#define M500A_H

#ifdef __cplusplus
extern "C"
{
#endif

// General Include File for serveral defines concerning conditional library
// compilation and microcontroller usage
//#include <MfOsDefs.h>


// P I C C - C O M M A N D S
// commands which are handled by the tag
// Each tag command is written to the reader IC and transfered via RF
#define PICC_REQSTD        0x26			// request idle
#define PICC_REQALL        0x52			// request all
#define PICC_ANTICOLL1     0x93			// anticollision level 1
#define PICC_ANTICOLL2     0x95			// anticollision level 2
#define PICC_ANTICOLL3     0x97			// anticollision level 3
#define PICC_AUTHENT1A     0x60			// authentication step 1
#define PICC_AUTHENT1B     0x61			// authentication step 2
#define PICC_READ          0x30			// read block
#define PICC_WRITE         0xA0			// write block
#define PICC_DECREMENT     0xC0         	// decrement value
#define PICC_INCREMENT     0xC1         	// increment value
#define PICC_RESTORE       0xC2         	// restore command code
#define PICC_TRANSFER      0xB0         	// transfer command code
#define PICC_HALT          0x50			// halt

// Mifare Error Codes
// Each function returns a status value, which corresponds to the
// mifare error codes. 
#define MI_OK                           0
#define MI_CHK_OK                       0
#define MI_CRC_ZERO                     0

#define MI_CRC_NOTZERO                  1

#define MI_NOTAGERR                     (-1)
#define MI_CHK_FAILED                   (-1)
#define MI_CRCERR                       (-2)
#define MI_CHK_COMPERR                  (-2)
#define MI_EMPTY                        (-3)
#define MI_AUTHERR                      (-4)
#define MI_PARITYERR                    (-5)
#define MI_CODEERR                      (-6)

#define MI_SERNRERR                     (-8)
#define MI_KEYERR                       (-9)
#define MI_NOTAUTHERR                   (-10)
#define MI_BITCOUNTERR                  (-11)
#define MI_BYTECOUNTERR                 (-12)
#define MI_IDLE                         (-13)
#define MI_TRANSERR                     (-14)
#define MI_WRITEERR                     (-15)
#define MI_INCRERR                      (-16)
#define MI_DECRERR                      (-17)
#define MI_READERR                      (-18)
#define MI_OVFLERR                      (-19)
#define MI_POLLING                      (-20)
#define MI_FRAMINGERR                   (-21)
#define MI_ACCESSERR                    (-22)
#define MI_UNKNOWN_COMMAND              (-23)
#define MI_COLLERR                      (-24)
#define MI_RESETERR                     (-25)
#define MI_INITERR                      (-25)
#define MI_INTERFACEERR                 (-26)
#define MI_ACCESSTIMEOUT                (-27)
#define MI_NOBITWISEANTICOLL            (-28)
#define MI_QUIT                         (-30)

#define MI_RECBUF_OVERFLOW              (-50) 
#define MI_SENDBYTENR                   (-51)
	
#define MI_SENDBUF_OVERFLOW             (-53)
#define MI_BAUDRATE_NOT_SUPPORTED       (-54)
#define MI_SAME_BAUDRATE_REQUIRED       (-55)

#define MI_WRONG_PARAMETER_VALUE        (-60)

#define MI_BREAK                        (-99)
#define MI_NY_IMPLEMENTED               (-100)
#define MI_NO_MFRC                      (-101)
#define MI_MFRC_NOTAUTH                 (-102)
#define MI_WRONG_DES_MODE               (-103)
#define MI_HOST_AUTH_FAILED             (-104)

#define MI_WRONG_LOAD_MODE              (-106)
#define MI_WRONG_DESKEY                 (-107)
#define MI_MKLOAD_FAILED                (-108)
#define MI_FIFOERR                      (-109)
#define MI_WRONG_ADDR                   (-110)
#define MI_DESKEYLOAD_FAILED            (-111)

#define MI_WRONG_SEL_CNT                (-114)

#define MI_WRONG_TEST_MODE              (-117)
#define MI_TEST_FAILED                  (-118)
#define MI_TOC_ERROR                    (-119)
#define MI_COMM_ABORT                   (-120)
#define MI_INVALID_BASE                 (-121)
#define MI_MFRC_RESET                   (-122)
#define MI_WRONG_VALUE                  (-123)
#define MI_VALERR                       (-124)

// _____________________________________________________________________________
//
//  FUNCTION: M500PcdReset
//        IN: -
//       OUT: -
//    RETURN: MI_OK
//            MI_RESETERR
//            MI_INTERFACEERR
//   COMMENT: This function initiates a reset of the reader IC. Note, that
//            the reset pin of the reader has to be connected to the 
//            expected port pin of the microcontroller.
//
char M500PcdReset(void);

// _____________________________________________________________________________
//
//  FUNCTION: M500PcdConfig
//        IN: -
//       OUT: -
//    RETURN: MI_OK
//            MI_RESETERR
//            MI_INTERFACEERR
//   COMMENT: Configuration of the reader IC. This function has to be called
//            before the first data is written to the reader. A reset 
//            is initiated and several registers are set.
//
char M500PcdConfig(void);

// _____________________________________________________________________________
//
//  FUNCTION: M500PcdInOutSlaveConfig
//        IN: -
//       OUT: -
//    RETURN: MI_OK
//            MI_UNKNOWN_COMMAND
//            MI_ACCESSTIMEOUT
//   COMMENT: The reader IC is able to communicate with another reader IC
//            via the digital "mifare in" and "mifare out" interface. Therefore
//            one reader acts as a master and sends commands via "mifare out".
//            The other reader ic acts as a slave and receives data via
//            "mifare in" interface. The slave module can not be initialised
//            by the microcontroller because only the "mifare in/out"
//            interface is connected.For this reason, the slave module has 
//            to be initialised once. For that the appropriate parameter 
//            settings are written to 
//            the E2PROM. After POR (power on reset) the IC reads these settings
//            and initialises automatically as slave.
//
char M500PcdInOutSlaveConfig(void);

// _____________________________________________________________________________
//
//  FUNCTION: M500PcdInOutMasterConfig
//        IN: -
//       OUT: -
//    RETURN: MI_OK
//   COMMENT: Corresponding to the slave configuration routine. This function
//            initialises the master reader IC. The function is additional
//            to the standard configuration "M500PcdConfig".
//
char M500PcdInOutMasterConfig(void);

// _____________________________________________________________________________
//
//  FUNCTION: MfPcdLoadMk
//        IN: kl_mode     PICC_AUTHENT1A or PICC_AUTHENT1B 
//                              selects master key A or master key B 
//                        KS0, KS1, KS2 selects one of the three master key sets.
//            key_addr    spec. the key RAM address to which the data shall be 
//                        written (0..15)
//            mk          pointer to a 6 byte authentication key
//       OUT: -
//    RETURN: MI_OK
//   COMMENT: In order to be "calling compatibel" to former libraries, this 
//            function enables to store all keys in the microcontroller.
//            When calling the authentication function "M500PiccAuth", 
//            these keys can be used.
//            Note: This concept supports backward compatibility for the 
//            application software, but does not fulfill the same security 
//            level because keys are in this case stored autside the secure key 
//            memory of the MF RC500.
//
char M500PcdLoadMk(unsigned char  kl_mode, 
                   unsigned char  key_addr, 
                   unsigned char  *mk);
 
// _____________________________________________________________________________
//
//  FUNCTION: M500PcdLoadKeyE2
//        IN: key_type      PICC_AUTHENT1A or PICC_AUTHENT1B 
//            sector        key sector number, on which the key should be stored
//                          values from 0 to 15 are valid
//            uncoded_keys  6 bytes key 
//       OUT: -
//    RETURN: 
//   COMMENT: This function stores the keys in the reader internal E2PROM.
//            These keys are available for the function M500PiccAuthE2.
//                     
char M500PcdLoadKeyE2(unsigned char key_type,
                      unsigned char sector,
                      unsigned char *uncoded_keys); 

// _____________________________________________________________________________
//
//  FUNCTION: PcdReadE2
//        IN: startaddr     2 bytes of starting address of the E2PROM 
//            length        number of byte of data to be read
//       OUT: *_data        buffer for the read bytes 
//    RETURN: 
//   COMMENT: This functions reads out data stored in the MF RC500's EERPOM   
//	      beginning ataddress startaddr. The number of bytes to be read are  
//	      given by  the variablelength and the read out data are stored in  
//            the provided data buffer.
//
char PcdReadE2(unsigned short startaddr,  
               unsigned char length,
               unsigned char* _data);

// _____________________________________________________________________________
//
//  FUNCTION: PcdWriteE2
//        IN: startaddr     2 bytes of starting address of the E2PROM 
//            length        number of byte of data to be write
//       OUT: *_data        buffer for the write bytes 
//    RETURN: 
//   COMMENT: This function writes a given length of data bytes stored in the data  
// 	      buffer to the reader IC's EEPROM beginning at address <em>startaddr</em>. 
//
char PcdWriteE2(unsigned short startaddr,
                unsigned char length,
                unsigned char* _data);

// _____________________________________________________________________________
//
//  FUNCTION: M500PcdMfOutSelect
//        IN: type      The signal to be appear at MfOut pin 
//
//		000: Constant Low
//		001: Constant High
//		010: Modulation signal from the internal coder, Miller coded
//		011: Serial data stream, not Miller coded
//		100: Output signal of the energy carrier demodulator
//		101: Output signal of the subcarrier demodulator
//		110: RFU
//		111: RFU
//       OUT: -
//    RETURN: 
//   COMMENT: This function config the output of the MfOut pin
//                     
char M500PcdMfOutSelect(unsigned char type);
                     
// _____________________________________________________________________________
//
//  FUNCTION: M500PcdWriteRegister
//        IN: Reg      	Register address
//	      value	value to be written	 
//       OUT: -
//    RETURN: 
//   COMMENT: This function write the value to the RC500 register
//                     
char M500PcdWriteRegister(unsigned char Reg, unsigned char value);

// _____________________________________________________________________________
//
//  FUNCTION: M500PcdReadRegister
//        IN: Reg      	Register address 
//       OUT: -
//    RETURN: value	value of register
//   COMMENT: This function read the value of the RC500 register
//                     
char M500PcdReadRegister(unsigned char Reg);

// _____________________________________________________________________________
//
//  FUNCTION: M500PiccRequest
//        IN: rq_code  can take the following values
//                     ALL   Request Code 52hex is sent out to get also a 
//                           response from cards in halt state.
//                     IDLE  Request Code 26hex is sent out to get a response 
//                           only from cards that are not in halt state.
//                     Note: Future cards will work also with other request 
//                           codes.
//       OUT: atq      16 bit ATQ (answer to request). 
//                     atq[0] .. LSByte
//                     atq[1] .. MSByte
//    RETURN: 
//   COMMENT: This function accesses the reader module and activates sending the
//            REQ code to the MIFARE card. After sending the command to the card 
//            the function waits for the card's answer.
//
//            Please note, that the actual work is done by the function
//            M500PiccCommonRequest, because of the interface behaviour between
//            Mifare and ISO 14443
//
//            The Card replies the ATQ.
//
//            ATQ:
//
//                    +----+----+----+----+----+----+----+----+
//            LSByte  | b8 | b7 | b6 | b5 | b4 | b3 | b2 | b1 |
//                    +----+----+----+----+----+----+----+----+
//                    |         |    |                        |
//                    | UID size| RFU|   bit-frame anticoll   |
//                    |         |    |                        |
//                    | 00..std |    |  (if any bit set .. Y, |
//                    | 01..dbl |    |             else .. N) |
//                    | 10..tpl |    |                        |
//
//
//
//                    +----+----+----+----+----+----+----+----+
//            MSByte  | b8 | b7 | b6 | b5 | b4 | b3 | b2 | b1 |
//                    +----+----+----+----+----+----+----+----+
//                    |                                       |
//                    |                 RFU                   |
//                    |                                       |
//
char M500PiccRequest(unsigned char req_code, 
                       unsigned char *atq);
// _____________________________________________________________________________
//
//  FUNCTION: M500PiccCommonRequest
//        IN: rq_code  can take the following values
//                     ALL   Request Code 52hex is sent out to get also a 
//                           response from cards in halt state.
//                     IDLE  Request Code 26hex is sent out to get a response 
//                           only from cards that are not in halt state.
//                     Note: Future cards will work also with other request 
//                           codes.
//       OUT: atq      16 bit ATQ (answer to request). 
//                     atq[0] .. LSByte
//                     atq[1] .. MSByte
//    RETURN: 
//   COMMENT: Please note, that this function does the actual work which is 
//            described in function M500PiccRequest.
//
char M500PiccCommonRequest(unsigned char req_code, 
                             unsigned char *atq);  

// _____________________________________________________________________________
//
//  FUNCTION: M500PiccAnticoll
//        IN: bcnt       Number of snr-bits that are known (default value is 0)
//            *snr       4 bytes serial number (number of bits, which
//                       are known and indicated by "bcnt"
//       OUT: *snr       4 bytes serial number, determined by the anticollision
//                       sequence
//    RETURN: 
//   COMMENT: The actual anticollision loop is done by the function
//            "M500PiccCascAnticoll". Which is called with select_code 0x93.
//
char M500PiccAnticoll (unsigned char bcnt,
                         unsigned char *snr);

// _____________________________________________________________________________
//
//  FUNCTION: M500PiccCascAnticoll
//        IN: select_code    0x93  standard select code
//                           0x95  cascaded level 1
//                           0x97  cascaded level 2
//            bcnt       Number of snr-bits that are known (default value is 0)
//            *snr       4 bytes serial number (number of bits, which
//                       are known and indicated by "bcnt"
//       OUT: *snr       4 bytes serial number, determined by the anticollision
//                       sequence
//    RETURN: 
//   COMMENT: Corresponding to the specification in ISO 14443, this function
//            is able to handle extended serial numbers. Therefore more than
//            one select_code is possible. The function transmitts a 
//            select code and all ready tags are responding. The highest
//            serial number within all responding tags will be returned by 
//            this function.
//                     
char M500PiccCascAnticoll (unsigned char select_code,
                             unsigned char bcnt,
                             unsigned char *snr);                     

// _____________________________________________________________________________
//
//  FUNCTION: M500PiccSelect
//        IN: *snr      4 bytes serial number
//       OUT: *sak      1 byte select acknowledge
//			xxxxx1xx: Cascade bit set: UID not complete
//			xx1xx0xx: UID complete,
//				  PICC compliant with ISO/IEC 14443-4
//			xx0xx0xx: UID complete,
//				  PICC not compliant with ISO/IEC 14443-4
//    RETURN: 
//   COMMENT: The actual select procedure is done by the function
//            "M500PiccCascSelect". Which is called with select_code 0x93.
//             
char M500PiccSelect(unsigned char *snr, 
                      unsigned char *sak);

// _____________________________________________________________________________
//
//  FUNCTION: M500PiccCascSelect
//        IN: select_code 
//            *snr          4 bytes serial number
//       OUT: *sak          1 byte select acknowledge
//    RETURN: 
//   COMMENT: Selects a UID level, depending on select code.
//            Returns Select Acknowledge byte.
//
//            Corresponding to the specification in ISO 14443, this function
//            is able to handle extended serial numbers. Therefore more than
//            one select_code is possible.
//
//            Select codes:
//
//            +----+----+----+----+----+----+----+----+
//            | b8 | b7 | b6 | b5 | b4 | b3 | b2 | b1 |
//            +-|--+-|--+-|--+-|--+----+----+----+-|--+
//              |    |    |    |  |              | |
//                                |              |
//              1    0    0    1  | 001..std     | 1..bit frame anticoll
//                                | 010..double  |
//                                | 011..triple  |
//
//            SAK:
//
//            +----+----+----+----+----+----+----+----+
//            | b8 | b7 | b6 | b5 | b4 | b3 | b2 | b1 |
//            +-|--+-|--+-|--+-|--+-|--+-|--+-|--+-|--+
//              |    |    |    |    |    |    |    |
//                        |              |
//                RFU     |      RFU     |      RFU
//
//                        1              0 .. UID complete, ATS available
//                        0              0 .. UID complete, ATS not available
//                        X              1 .. UID not complete
//
char M500PiccCascSelect(unsigned char select_code, 
                            unsigned char *snr, 
                            unsigned char *sak); 

// _____________________________________________________________________________
//
//  FUNCTION: MfPiccAuth
//        IN: auth_mode PICC_AUTHENT1A or PICC_AUTHENT1B 
//                            selects master key A or master key B 
//                      KS0, KS1, KS2 selects one of the three master key sets.
//            *snr       4 byte serial number of the card, which should be 
//                       authenticated
//            key_sector spec. the key RAM address from which the data should be
//                      taken (0..15)
//            block     addresses the block address on the card, which shall be
//                      authenticated. For MIFARE standard cards, addr can take 
//                      a value from 0 to 63, for other card types please refer
//                      to the according product description.
//       OUT: -
//    RETURN: 
//   COMMENT: This function authenticates one card's sector (according to the 
//            block address addr) using the specified mode and master key, 
//            addressed with key_addr. After sending the command to the card the 
//            function waits for the card's answer.
//            This function is calling compatible (exept the serial number) with
//            older authentication functions. The keys are stored by the 
//            microcontroller, which is capable for the key management.
//
char M500PiccAuth(unsigned char auth_mode, 
                      unsigned char *snr,
                      unsigned char key_sector, 
                      unsigned char block);   
               
// _____________________________________________________________________________
//
//  FUNCTION: M500PiccAuthE2
//        IN: auth_mode PICC_AUTHENT1A or PICC_AUTHENT1B 
//                            selects master key A or master key B 
//            *snr       4 byte serial number of the card, which should be 
//                       authenticated
//            key_sector spec. the key E2PROM key number from which the data 
//                       should be taken (0..15)
//            sector    addresses the sector number on the card, which shall be
//                      authenticated. For MIFARE standard cards, addr can take 
//                      a value from 0 to 15, for other card types please refer
//                      to the according product description.
//       OUT: -
//    RETURN: 
//   COMMENT: This function authenticates one card's sector using the specified 
//            mode. After sending the command to the card the 
//            function waits for the card's answer.
//            The keys for authentication have to be stored in E2PROM in 
//            advance.
char M500PiccAuthE2( unsigned char auth_mode, 
                         unsigned char *snr,      
                         unsigned char key_sector,
                         unsigned char sector); 
                     
// _____________________________________________________________________________
//
//  FUNCTION: M500HostCodeKey
//        IN: uncoded   6 bytes master key for card authentication
//       OUT: coded     12 bytes master key for card authentication
//    RETURN: 
//   COMMENT: In order to authenticate a memory sector of a card, a 6 
//            bytes master key is necessary. This master key has to be passed
//            to the reader modul coded. The conversion between uncoded and 
//         	  coded keys is made by this function.
//                     
char M500HostCodeKey(unsigned char *uncoded, 
                         unsigned char *coded); 

// _____________________________________________________________________________
//
//  FUNCTION: M500PiccAuthKey
//        IN: auth_mode PICC_AUTHENT1A or PICC_AUTHENT1B 
//                            selects master key A or master key B 
//            *snr       4 byte serial number of the card, which should be 
//                       authenticated
//            *keys      12 bytes master key coded
//            sector    addresses the sector number on the card, which shall be
//                      authenticated. For MIFARE standard cards, addr can take 
//                      a value from 0 to 15, for other card types please refer
//                      to the according product description.
//       OUT: -
//    RETURN: 
//   COMMENT: The keys are first loaded to the reader module and used for
//            authentication of the secified sector. In order to get the 
//            required keys coded, the function M500HostCodeKey can be used.
//                     
char M500PiccAuthKey(unsigned char auth_mode,
                         unsigned char *snr,   
                         unsigned char *keys,  
                         unsigned char sector);   
                     
                        
// _____________________________________________________________________________
//
//  FUNCTION: M500PiccRead
//        IN: addr    addresses -  the block on the card from which data shall 
//                    be read. For MIFARE standard cards, addr can take a value
//                    from 0 to 63 (255 for Mifare Pro), for other card types 
//                    please refer to the according product description.
//       OUT: data    is a pointer to the 16 byte data block read from the card.
//       OUT: 
//    RETURN: 
//   COMMENT: This function reads a 16 byte block from the specified card's block 
//            address addr. After sending the command to the card the function 
//            waits for the card's answer.
//                        
char M500PiccRead(unsigned char addr,  
                  unsigned char *_data);
                 
// _____________________________________________________________________________
//
//  FUNCTION: M500PiccWrite
//        IN: addr     address -  the block on the card from which data shall 
//                     be read. For MIFARE standard cards, addr can take a 
//                     value from 0 to 63 (255 for Mifare Pro), for other card 
//                     types please refer to the according product description.
//            data     is a pointer to the 16 byte data block that shall be 
//                     written to the card.
//       OUT: -
//    RETURN: 
//   COMMENT: This function writes a 16 byte block to the specified card's block 
//            address addr. After sending the command to the card the function
//            waits for the card's answer.
//                  
char M500PiccWrite(unsigned char addr,
                       unsigned char *_data);
                  

// _____________________________________________________________________________
//
// FUNCTION: M500PiccValue
//	 IN: dd_mode	INCREMENT, DECREMENT or RESTORE
//	     addr	Block address for the command to be perform 0-63
//	     *value	4 bytes value, LSB first
//	     trans_addr Destination block address to be tranfer	
//	OUT: -
//  COMMENT:
// This function performs the INCREMENT, DECREMENT and RESTORE command. Precondition 
// for success is, that the data block is formatted as value block. 
//
// For INCREMENT and DECREMENT, the command doesn't write back the value to the memory 
// location directly, but loads the transfer buffer with the increased value,
// which could be transferred to any authenticated block by the TRANFER command.
//
// The RESTORE command loads the transfer buffer with the value stored at datablock 
// address, while the 
// given value is only a dummy value, which only have to be in valid range. 
// With a subsquent TRANSFER command a backup management for Value Blocks is 
// established.
//
// After sending the command to the card the function waits for the 
// card's answer. In case of an error <em>Mf500PiccValue()</em>
// generates a return code according to the MF RC's error flags, otherwise 
// the value is sent to the card and then it waits for a NACK. As an exception 
// in this protocol step 
// only a NACK is sent by the card in case of an error. Thus, the function 
// is successful, if a time out occurs. 
//
// After the calculation is done,  a TRANSFER is automatically
// performed to the block address trans_addr. After sending the command to
// the card the function waits for the card's answer 
// and generates a return code according to the MF RC's error flags. 
// A TRAN command is only possible directly after a RESTORE, INCREMENT or 
// DECREMENT command.
//
// The value inside a Value Block is four bytes wide and stored two times
// in normal and one time in bit-inverted manner for data security issues. 
// Additionally the initial address of the Value Block is stored two times 
// normal and two times bit-inverted. In case of a backup of a Value Block, 
// this addres contains the original address of the Value Block.
// Note: Only positive numbers are alowed for the parameter <em>value</em>.
//
char M500PiccValue(unsigned char dd_mode, 
                   unsigned char addr, 
                   unsigned char *value,
                   unsigned char trans_addr);

// _____________________________________________________________________________
//
// FUNCTION: M500PiccValueDebit
//	 IN: dd_mode	INCREMENT, DECREMENT or RESTORE
//	     addr	Block address for the command to be perform 0-63
//	     *value	4 bytes value, LSB first
//	OUT: -
//  COMMENT:
// This function executes calculations on value debit blocks with cards, that 
// support automatic transfer (MIFARE light, MIFARE PLUS, MIFARE PRO,
// MIFARE PROX, ...). 
//
// After sending the command 
// to the card the function waits for the card's answer. In case of an error 
// it generates a return code according 
// to the MF RC's error flags. 
//
char M500PiccValueDebit(unsigned char dd_mode, 
                        unsigned char addr, 
                        unsigned char *value);

// _____________________________________________________________________________
//
// FUNCTION: M500PiccExchangeBlock
//	 IN: *send_data	
//	     send_bytelen       Lenght include 2bytes CRC
//	     append_crc		1->append, 0->not append
//	     timeout		Set duration of timeout timer
//				1-> 1s
//				2-> 1.5s
//				3-> 6s
//				4-> 9.6s
//	OUT: *rec_data
//	     *rec_bytelen
//  COMMENT:
// This function exchanges data blocks between the <b>PCD</b> and <b>PICC</b>. 
//
// ATTENTION: if <em>append_crc</em> is enabled, two CRC bytes are included in 
// <em>send_bytelen</em> and <em>rec_bytelen</em>. The received CRC bytes in the
// receive buffer are always set to zero. 
//
char M500PiccExchangeBlock(unsigned char *send_data,
                           unsigned char send_bytelen,
                           unsigned char *rec_data,  
                           unsigned char *rec_bytelen,
                           unsigned char append_crc, 
                           unsigned char timeout);                  

// _____________________________________________________________________________
//
//  FUNCTION: M500PiccHalt
//        IN: -
//       OUT: -
//    RETURN: -
//   COMMENT: This function sets the MIFARE card into the halt state. After 
//            sending the command to the card the function waits for a cards 
//            response. As an exception, in this protocol step no ACK is sent by
//            the card, but only a NACK in case of an error. Thus, the function 
//            is successful, if a time out occurs.
//                  
char M500PiccHalt(void);

// _____________________________________________________________________________
//
//  FUNCTION: MfPcdRfReset
//        IN: msec     Duration of RF-field off in mseconds.
//                     If parameter msec is 0 => RF OFF forever
//       OUT: -
//    GLOBAL: -
//    RETURN: 
//   COMMENT: Turns off RF-field for a certain time in mseconds. The period
//            is specified in variable 'msec'. Subsequently RF-field is
//            turned on again (after about 1 msec). If value 0 is chosen, 
//            the RF-field is simply turned off. 
//
char M500PcdRfReset(unsigned char ms);                  

void idle_request(void);

#ifdef __cplusplus
}
#endif

#endif
