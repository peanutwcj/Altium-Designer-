///////////////////////////////////////////////////////////////////////////////
//    Copyright (c), Philips Semiconductors Gratkorn
//
//                  (C)PHILIPS Electronics N.V.2000
//                     All rights are reserved. 
//  Philips reserves the right to make changes without notice at any time.
// Philips makes no warranty, expressed, implied or statutory, including but
// not limited to any implied warranty of merchantibility or fitness for any
//particular purpose, or that the use will not infringe any third party patent,
// copyright or trademark. Philips must not be liable for any loss or damage
//                          arising from its use.
///////////////////////////////////////////////////////////////////////////////
#define DLL_EXPORT      // library source module definition

#include <string.h>
#include <stdio.h>

#include <RICReg.h>

#include <PcdUtils.h>
#include <MfRc500.h>
#include <RcCommunication.h>
#include <MfErrNo.h>
#include <CPURegs.h>
#include <uCInit.h>

volatile unsigned char RxTxBuffer[MAX_RF_BUF_SIZE];

// communication info stucture
static   volatile MfCmdInfo     *MpIsrInfo = 0; 
// ISR send buffer
static   volatile unsigned char *MpIsrOut = 0; 
// ISR receive buffer
static   volatile unsigned char *MpIsrIn = 0;   

///////////////////////////////////////////////////////////////////////
//         S e t   T i m e o u t   L E N G T H
///////////////////////////////////////////////////////////////////////
void PcdSetTmo(unsigned char tmoLength)
{
   switch(tmoLength)
   {  // timer clock frequency 13,56 MHz
      case 1:                         // short timeout (1,0 ms)
         WriteRC(RegTimerClock,0x07); // TAutoRestart=0,TPrescale=128
         WriteRC(RegTimerReload,0x6a);// TReloadVal = 'h6a =106(dec) 
         break;
      case 2:                       // medium timeout (1,5 ms)
         WriteRC(RegTimerClock,0x07); // TAutoRestart=0,TPrescale=128
         WriteRC(RegTimerReload,0xa0);// TReloadVal = 'ha0 =160(dec) 
         break;
      case 3:                       // long timeout (6 ms)
         WriteRC(RegTimerClock,0x09); // TAutoRestart=0,TPrescale=4*128
         WriteRC(RegTimerReload,0xa0);// TReloadVal = 'ha0 =160(dec) 
         break;
      case 4:                       // long timeout (9.6 ms)
         WriteRC(RegTimerClock,0x09); // TAutoRestart=0,TPrescale=4*128
         WriteRC(RegTimerReload,0xff);// TReloadVal = 'ff =255(dec) 
         break;
      default:                       // short timeout (1,0 ms)
         WriteRC(RegTimerClock,0x07); // TAutoRestart=0,TPrescale=128
         WriteRC(RegTimerReload,tmoLength);// TReloadVal = tmoLength
         break;
   }     
}

//////////////////////////////////////////////////////////////////////
//   S E T   A   B I T   M A S K 
///////////////////////////////////////////////////////////////////////
void SetBitMask(unsigned char reg,unsigned char mask) // 
{
   char   tmp    = 0x0;

   tmp = ReadRC(reg);
   WriteRC(reg,tmp | mask);  // set bit mask
}

//////////////////////////////////////////////////////////////////////
//   C L E A R   A   B I T   M A S K 
///////////////////////////////////////////////////////////////////////
void ClearBitMask(unsigned char reg,unsigned char mask) // 
{
   char   tmp    = 0x0;

   tmp = ReadRC(reg);
   WriteRC(reg,tmp & ~mask);  // clear bit mask
}

///////////////////////////////////////////////////////////////////////
//                  F L U S H    F I F O
///////////////////////////////////////////////////////////////////////
void FlushFIFO(void)
{  
   SetBitMask(RegControl,0x01);
}

///////////////////////////////////////////////////////////////////////////////
//                       Interrupt Handler RIC
///////////////////////////////////////////////////////////////////////////////
void SingleResponseIsr(void)
{
   static unsigned char  irqBits;
   static unsigned char  irqMask;            
   static unsigned char  oldPageSelect;
   static unsigned char  nbytes;
   static unsigned char  cnt;

   if (MpIsrInfo && MpIsrOut && MpIsrIn)  // transfer pointers have to be set
                                          // correctly
   {
      oldPageSelect = ReadRawRC(RegPage); // save old page select 
                                          // Attention: ReadRC cannnot be
                                          // used because of the internal
                                          // write sequence to the page 
                                          // reg
      WriteRawRC(RegPage,0x80);                   // select page 0 for ISR
      while( (ReadRawRC(RegPrimaryStatus) & 0x08)) // loop while IRQ pending
      {
         irqMask = ReadRawRC(RegInterruptEn); // read enabled interrupts
         // read pending interrupts
         irqBits = ReadRawRC(RegInterruptRq) & irqMask;
         MpIsrInfo->irqSource |= irqBits; // save pending interrupts
         //************ LoAlertIRQ ******************
         if (irqBits & 0x01)    // LoAlert
         {  
            nbytes = MFIFOLength - ReadRawRC(RegFIFOLength);
            // less bytes to send, than space in FIFO
            if ((MpIsrInfo->nBytesToSend - MpIsrInfo->nBytesSent) <= nbytes)
            {
               nbytes = MpIsrInfo->nBytesToSend - MpIsrInfo->nBytesSent;
             WriteRawRC(RegInterruptEn,0x01); // disable LoAlert IRQ
            }
            // write remaining data to the FIFO
            for ( cnt = 0;cnt < nbytes;cnt++)
            {
               WriteRawRC(RegFIFOData,MpIsrOut[MpIsrInfo->nBytesSent]);
               MpIsrInfo->nBytesSent++;
            }
            WriteRawRC(RegInterruptRq,0x01);  // reset IRQ bit
         }
      
         //************* TxIRQ Handling **************
         if (irqBits & 0x10)       // TxIRQ
         {
            WriteRawRC(RegInterruptRq,0x10);    // reset IRQ bit 
            WriteRawRC(RegInterruptEn,0x82);    // enable HiAlert Irq for
                                                // response
            if (MpIsrInfo->cmd == PICC_ANTICOLL1) // if cmd is anticollision
            {                                     // switch off parity generation
               WriteRC(RegChannelRedundancy,0x02); // RxCRC and TxCRC disable, parity disable               
               WriteRawRC(RegPage,0x00);  // reset page address
            }
         }

         //************* HiAlertIRQ or RxIRQ Handling ******************
         if (irqBits & 0x0E) // HiAlert, Idle or RxIRQ
         {
            // read some bytes ( length of FIFO queue)              
            // into the receive buffer
            nbytes = ReadRawRC(RegFIFOLength);
            // read date from the FIFO and store them in the receive buffer
            for ( cnt = 0; cnt < nbytes; cnt++)               
            {
               MpIsrIn[MpIsrInfo->nBytesReceived] = ReadRawRC(RegFIFOData);
               MpIsrInfo->nBytesReceived++;
            }
            WriteRawRC(RegInterruptRq,0x0A & irqBits);  
                                       // reset IRQ bit - idle irq will
                                       // be deleted in a seperate section
         }   
   
         //************** IdleIRQ Handling ***********
         if (irqBits & 0x04)     // Idle IRQ
         {
            WriteRawRC(RegInterruptEn,0x20); // disable Timer IRQ
            WriteRawRC(RegInterruptRq,0x20); // disable Timer IRQ request
            irqBits &= ~0x20;   // clear Timer IRQ in local var
            MpIsrInfo->irqSource &= ~0x20; // clear Timer IRQ in info var
                                        // when idle received, then cancel
                                        // timeout
            WriteRawRC(RegInterruptRq,0x04);  // reset IRQ bit 
            // status should still be MI_OK
            // no error - only used for wake up
         }
       
         //************* TimerIRQ Handling ***********
         if (irqBits & 0x20)       // timer IRQ
         {
            WriteRawRC(RegInterruptRq,0x20); // reset IRQ bit 
            MpIsrInfo->status = MI_NOTAGERR; // timeout error
                                             // otherwise ignore the interrupt
         }
         
      }
      WriteRawRC(RegPage,oldPageSelect | 0x80);
   }
}

//////////////////////////////////////////////////////////////////////
//       W R I T E   A   P C D   C O M M A N D 
///////////////////////////////////////////////////////////////////////
char  PcdSingleResponseCmd(unsigned char cmd,
               volatile unsigned char* send, 
               volatile unsigned char* rcv,
               volatile MfCmdInfo *info)
{     
   char          status    = MI_OK;
   char          tmpStatus ;
   unsigned char lastBits;

   unsigned char irqEn     = 0x00;
   unsigned char waitFor   = 0x00;
   unsigned char timerCtl  = 0x00;

   WriteRC(RegInterruptEn,0x7F); // disable all interrupts
   WriteRC(RegInterruptRq,0x7F); // reset interrupt requests
   WriteRC(RegCommand,PCD_IDLE); // terminate probably running command

   FlushFIFO();            // flush FIFO buffer

   // save info structures to module pointers
   MpIsrInfo = info;  
   MpIsrOut  = send;
   MpIsrIn   = rcv;

   // initialising the ISR-Function pointer for mifare
   // protocol - do this after initialising the MpXXXX variables
   PcdIsrFct = SingleResponseIsr; 
                         
   info->irqSource = 0x0; // reset interrupt flags

   READER_INT_ENABLE;

   // depending on the command code, appropriate interrupts are enabled (irqEn)
   // and the commit interrupt is choosen (waitFor).
   switch(cmd)
   {
      case PCD_IDLE:                   // nothing else required
         irqEn = 0x00;
         waitFor = 0x00;
         break;
      case PCD_WRITEE2:                // LoAlert and TxIRq
         irqEn = 0x11;
         waitFor = 0x10;
         break;
      case PCD_READE2:                 // HiAlert, LoAlert and IdleIRq
         irqEn = 0x07;
         waitFor = 0x04;
         break;
      case PCD_LOADCONFIG:             // IdleIRq and LoAlert
      case PCD_LOADKEYE2:              // IdleIRq and LoAlert
      case PCD_AUTHENT1:               // IdleIRq and LoAlert
         irqEn = 0x05;
         waitFor = 0x04;
         break;
      case PCD_CALCCRC:                // LoAlert and TxIRq
         irqEn = 0x11;
         waitFor = 0x10;
         break;
      case PCD_AUTHENT2:               // IdleIRq
         irqEn = 0x04;
         waitFor = 0x04;
         break;
      case PCD_RECEIVE:                // HiAlert and IdleIRq
         info->nBitsReceived = -(ReadRC(RegBitFraming) >> 4);      
         irqEn = 0x06;
         waitFor = 0x04;
         break;
      case PCD_LOADKEY:                // IdleIRq
         irqEn = 0x05;
         waitFor = 0x04;
         break;
      case PCD_TRANSMIT:               // LoAlert and IdleIRq
         irqEn = 0x05;
         waitFor = 0x04;
         break;
      case PCD_TRANSCEIVE:             // TxIrq, RxIrq, IdleIRq and LoAlert
         info->nBitsReceived = -(ReadRC(RegBitFraming) >> 4);
         irqEn = 0x3D;
         waitFor = 0x04;
         break;
      default:
         status = MI_UNKNOWN_COMMAND;
   }        
   if (status == MI_OK)
   {
      // Initialize uC Timer for global Timeout management
      irqEn |= 0x20;                        // always enable timout irq
      waitFor |= 0x20;                      // always wait for timeout 

      GT_vInitTmr(TIMER_3,0x87);          // initialise and start
      GT_vLoadTmr(TIMER_3,0xF00);        // guard timer for reader 

      GT_vInitTmr(TIMER_4,0x04);          // initialise and start
      GT_vLoadTmr(TIMER_4,0x01);        // processing time counter
                                        // 6.4 us resolution - max 420 ms 

      LED_ON;                                        
      WriteRC(RegInterruptEn,irqEn | 0x80);  //necessary interrupts are enabled // count up from 1
      
      GT_vStartTmr(TIMER_3);            // start timer 3
      GT_vStartTmr(TIMER_4);            // start timer 4

      WriteRC(RegCommand,cmd);               //start command   

      // wait for commmand completion
      // a command is completed, if the corresponding interrupt occurs
      // or a timeout is signaled  

      while (!(MpIsrInfo->irqSource & waitFor
               || T3IR));                // wait for cmd completion or timeout

      WriteRC(RegInterruptEn,0x7F);          // disable all interrupts
      WriteRC(RegInterruptRq,0x7F);          // clear all interrupt requests
      SetBitMask(RegControl,0x04);         // stop timer now

      GT_vStopTmr(TIMER_4);
      GT_vStopTmr(TIMER_3);
      LED_OFF;

      T3IR = 0;
      WriteRC(RegCommand,PCD_IDLE);          // reset command register

      if (!(MpIsrInfo->irqSource & waitFor))   // reader has not terminated
      {                                        // timer 3 expired
         status = MI_ACCESSTIMEOUT;
      }
      else
         status = MpIsrInfo->status;           // set status

      if (status == MI_OK)                     // no timeout error occured
      {
         if ((tmpStatus = (ReadRC(RegErrorFlag) & 0x17))) // error occured
         {
            if (tmpStatus & 0x01)   // collision detected
            {
               info->collPos = ReadRC(RegCollPos); // read collision position
               status = MI_COLLERR;
            }
            else
            {
               info->collPos = 0;
               if (tmpStatus & 0x02)   // parity error
               {
                  status = MI_PARITYERR;
               }
            }
            if (tmpStatus & 0x04)   // framing error
            {
               status = MI_FRAMINGERR;
            }
            if (tmpStatus & 0x10)   // FIFO overflow
            {
               FlushFIFO();
               status = MI_OVFLERR;
            }
            if (tmpStatus & 0x08) // CRC error
            {
               status = MI_CRCERR;
            }
            if (status == MI_OK)
               status = MI_NY_IMPLEMENTED;
            // key error occures always, because of 
            // missing crypto 1 keys loaded
         }
         // if the last command was TRANSCEIVE, the number of 
         // received bits must be calculated - even if an error occured
         if (cmd == PCD_TRANSCEIVE || cmd == PCD_RECEIVE)
         {
            // number of bits in the last byte
            lastBits = ReadRC(RegSecondaryStatus) & 0x07;
            if (lastBits)
               info->nBitsReceived += (info->nBytesReceived-1) * 8 + lastBits;
            else
               info->nBitsReceived += info->nBytesReceived * 8;
         }
      }
      else
      {
         info->collPos = 0x00;
      }
   }

   READER_INT_DISABLE;

   PcdIsrFct = EmptyPcdIsrFct; // reset the ISR-Function pointer to
                               // an empty function body
                               // do this before clearing the Mp XXXX variables

   MpIsrInfo = 0;         // reset interface variables for ISR
   MpIsrOut  = 0;
   MpIsrIn   = 0; 
   return status;
}   
