 ///////////////////////////////////////////////////////////////////////////////
//    Copyright (c), Philips Semiconductors Gratkorn
//
//                     (C)PHILIPS Electronics N.V. 2000
//                        All rights are reserved. 
//  Philips reserves the right to make changes without notice at any time.
// Philips makes no warranty, expressed, implied or statutory, including but
// not limited to any implied warranty of merchantibility or fitness for any
//particular purpose, or that the use will not infringe any third party patent,
// copyright or trademark. Philips must not be liable for any loss or damage
//                          arising from its use.
///////////////////////////////////////////////////////////////////////////////

#ifndef PCDSHARED_H
#define PCDSHARED_H

#ifdef __cplusplus
extern "C"
{
#endif

// General Include File for serveral defines concerning conditional library
// compilation and microcontroller usage
#include "OsDefs.h"

/* 
* If the MF RC500 reset pin is connected to a dedicated �Controller port pin, 
* a reset can be performed. After each reset, the  automatic interface 
* recognition of the reader IC is activated. Both, resetting the reader IC 
* and determining the interface is done by this function. 
*/
FCT_PREF PcdReset(void);

/*
* In combination with
* a transparent register read and write command set, this function
* enables a completely transparant communication with the Reader IC
* and therefore every command can be coded either on the PC
* or on the microcontroller.
* Neither timout values nor CRC and parity generation are modified
* by this function.These parameters should be set in advance.
*/
FCT_PREF ExchangeByteStream(unsigned char Cmd,
                            unsigned char *send_data,
                            unsigned char send_bytelen,
                            unsigned char *rec_data,  
                            unsigned char *rec_bytelen);

/*
* This function reads out the 4 bytes serial number of the reader IC.
* The serial number is unique for all delivered readers.
*/
FCT_PREF PcdGetSnr(unsigned char *snr);

/*
* This functions reads out data stored in the MF RC500's EERPOM  beginning at 
* address startaddr. The number of bytes to be read are  given by  the variable
* length and the read out data are stored in the provided data buffer. 
*/
FCT_PREF PcdReadE2(unsigned short startaddr,  
                   unsigned char length,
                   unsigned char* data);

/*                  containing the data to be written to the EEPROM.
* \return CCE
*
* This function writes a given length of data bytes stored in the data buffer 
* to the reader IC's EEPROM beginning at address <em>startaddr</em>. 
*/
FCT_PREF PcdWriteE2(  unsigned short startaddr,
                      unsigned char length,
                      unsigned char* data);

/*
* This function turns off the RF-field for a specified time in milliseconds 
* by setting the variable ms. Elapsing this time the RF-field is turned on 
* approximately 1 millisecond later.
*
* If ms is set to 0 , the RF-field is turned off. 
*/
FCT_PREF PcdRfReset(unsigned short ms);                  


#ifdef __cplusplus
}
#endif

#endif