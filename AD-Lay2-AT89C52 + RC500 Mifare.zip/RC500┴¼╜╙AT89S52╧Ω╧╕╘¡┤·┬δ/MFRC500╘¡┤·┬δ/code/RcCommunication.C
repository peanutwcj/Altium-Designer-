#include <RcCommunication.h>
#include <MfErrNo.h>
#include <CPURegs.h>

///////////////////////////////////////////////////////////////////////////////
//                 Module Definitions
///////////////////////////////////////////////////////////////////////////////
#ifndef GetRegPage
 #define GetRegPage(adr) (0x80 | (adr>>3))
#endif

unsigned char * const gpcRCBaseAddress = (unsigned char * const)(MEMORY_BASE_ADDRESS);


  
///////////////////////////////////////////////////////////////////////////////
//                 Open Reader Communication
///////////////////////////////////////////////////////////////////////////////
char OpenRC(void)
{
   signed char status = MI_OK;


   	READER_INIT_RESET;

   return status;
}

///////////////////////////////////////////////////////////////////////////////
//                 Close Reader Communication
///////////////////////////////////////////////////////////////////////////////
void CloseRC(void)
{
}


///////////////////////////////////////////////////////////////////////////////
//          G E N E R I C    W R I T E
///////////////////////////////////////////////////////////////////////////////
void WriteRC(unsigned char Address, unsigned char value)
{
   WriteRawRC(0x00,GetRegPage(Address));   // select appropriate page
   WriteRawRC(Address,value);              // write value at the specified 
                                           // address
}

///////////////////////////////////////////////////////////////////////////////
//          G E N E R I C    R E A D
///////////////////////////////////////////////////////////////////////////////
unsigned char ReadRC(unsigned char Address)
{

   WriteRawRC(0x00,GetRegPage(Address));   // select appropriate page
   return ReadRawRC(Address);              // read value at the specified 
   
}  

///////////////////////////////////////////////////////////////////////////////
//     W R I T E   S E V E R A L   M E M O R Y   L O C A T I O N S 
///////////////////////////////////////////////////////////////////////////////
void WriteRCMultiple(unsigned char *Addr_Data, unsigned short len)
{
   static unsigned short cnt;

   for (cnt = 0; cnt < len; cnt++)
   {
       WriteRawRC(0x00,GetRegPage(Addr_Data[cnt*2]));// select appropriate page
        // write value at the specified address
       WriteRawRC(Addr_Data[cnt*2],Addr_Data[cnt * 2 + 1]); 
   }
}

///////////////////////////////////////////////////////////////////////////////
//     R E A D   S E V E R A L   M E M O R Y   L O C A T I O N S 
///////////////////////////////////////////////////////////////////////////////
void ReadRCMultiple(unsigned char* Addr_Data, unsigned short len)
{
   static unsigned short cnt;

   for (cnt = 0; cnt < len; cnt++)
   {
       WriteRawRC(0x00,GetRegPage(Addr_Data[cnt*2]));// select appropriate page
       Addr_Data[cnt*2 + 1] = ReadRawRC(Addr_Data[cnt*2]);// read value at the 
                                                      // specified address
   }
}  